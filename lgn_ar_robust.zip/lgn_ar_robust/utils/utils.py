import torch
import numpy as np
import math
from scipy.special import gamma
from scipy.ndimage import gaussian_filter


def get_distance(a, b):
    l0 = torch.norm((a - b).view(a.shape[0], -1), p=0, dim=1)
    l2 = torch.norm((a - b).view(a.shape[0], -1), p=2, dim=1)
    mse = (a - b).view(a.shape[0], -1).pow(2).mean(1)
    linf = torch.norm((a - b).view(a.shape[0], -1), p=float('inf'), dim=1)
    return l0, l2, mse, linf

def compute_niqe(image):
    # Load the pre-trained model parameters
    model_mat = scipy.io.loadmat('/kaggle/input/cifar-grad-mat/model_cifar_grad (1).mat')
    model_mu = model_mat['mu_prisparam']
    model_cov = model_mat['cov_prisparam']

    features = None
    img_scaled = image
    for scale in [1, 2]:
        if scale != 1:
            img_scaled = skimage.transform.rescale(image, 1/scale, anti_aliasing=True)

        img_norm = normalize_image(img_scaled)

        scale_features = []
        block_size = max(8 // scale, 1)
        for block_col in range(max(1, img_norm.shape[0] // block_size)):
            for block_row in range(max(1, img_norm.shape[1] // block_size)):
                block_features = compute_features(
                    img_norm[block_col * block_size:(block_col + 1) * block_size,
                             block_row * block_size:(block_row + 1) * block_size])
                
                block_features = [0 if np.isnan(f) else f for f in block_features]
                scale_features.append(block_features)

        if features is None:
            features = np.vstack(scale_features)
        else:
            features = np.hstack([features, np.vstack(scale_features)])

    features = np.nan_to_num(features)

    features_mu = np.mean(features, axis=0)
    features_cov = np.cov(features.T)

    epsilon = 1e-8
    pseudoinv_of_avg_cov = np.linalg.pinv((model_cov + features_cov) / 2 + epsilon * np.eye(features_cov.shape[0]))

    try:
        niqe_quality = math.sqrt((model_mu - features_mu).dot(pseudoinv_of_avg_cov.dot((model_mu - features_mu).T)))
    except Exception as e:
        niqe_quality = np.nan

    return niqe_quality
