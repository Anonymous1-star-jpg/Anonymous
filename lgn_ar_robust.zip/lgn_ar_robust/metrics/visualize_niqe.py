import numpy as np
import matplotlib.pyplot as plt
from torchvision import datasets, transforms
from utils.utils import compute_niqe  # Assuming the compute_niqe function is in utils.py

# Load CIFAR-10 images
transform = transforms.Compose([
    transforms.ToTensor(),
])

# Load CIFAR-10 dataset
cifar10_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

# Load precomputed LPIPS indices to display the same images
best_robust_indices = np.load('best_robust_indices.npy')

# Load NIQE scores
niqe_scores = np.load('niqe_scores.npy')

# Plot NIQE results
nrows = 4  
ncols = len(best_robust_indices)  # Should be 10 for all CIFAR-10 classes
fig, axs = plt.subplots(nrows=nrows, ncols=ncols, figsize=(20, 12))

for i, idx in enumerate(best_robust_indices):
    # Original CIFAR-10 image
    img = cifar10_dataset.data[idx]
    niqe_original = niqe_scores[idx]
    axs[0, i].imshow(img)
    axs[0, i].axis('off')
    axs[0, i].set_title(f"NIQE: {niqe_original:.2f}")

    # Robust model's gradient
    robust_grad_img = (robust_gradients[idx].permute(1, 2, 0).numpy() * 127.5 + 128).clip(0, 255).astype(np.uint8)
    niqe_robust_grad = compute_niqe(robust_grad_img)
    axs[2, i].imshow(robust_grad_img)
    axs[2, i].axis('off')
    axs[2, i].set_title(f"NIQE: {niqe_robust_grad:.2f}")

    # Standard model's gradient
    standard_grad_img = (standard_gradients[idx].permute(1, 2, 0).numpy() * 127.5 + 128).clip(0, 255).astype(np.uint8)
    niqe_standard_grad = compute_niqe(standard_grad_img)
    axs[3, i].imshow(standard_grad_img)
    axs[3, i].axis('off')
    axs[3, i].set_title(f"NIQE: {niqe_standard_grad:.2f}")

plt.tight_layout()
plt.savefig('comparison_niqe_plot.png', dpi=1000)
plt.show()
