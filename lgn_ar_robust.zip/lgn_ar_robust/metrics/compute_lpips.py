import torch
import lpips
import torch_utils
from utils import dnnlib
import numpy as np
from tqdm import tqdm
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from models.model import ResNet18  # Assuming your model is defined in models/model.py

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load the Robust and Standard Models
robust_model_path = "/kaggle/input/noise0-2mistaken-lr-cifar10/checkpoint_epoch_150.pth.tar"
standard_model_path = "/kaggle/input/standard-model/checkpoint_epoch_10.pth.tar"

robust_model = ResNet18().to(device)
robust_model.load_state_dict(torch.load(robust_model_path, map_location=device)['state_dict'])
robust_model.eval()

standard_model = ResNet18().to(device)
standard_model.load_state_dict(torch.load(standard_model_path, map_location=device)['state_dict'])
standard_model.eval()

# Load the test dataset
transform = transforms.Compose([transforms.ToTensor()])
testset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
testloader = DataLoader(testset, batch_size=32, shuffle=False, num_workers=2)

# Function to compute input gradients
def input_gradient_sum(model, img, device='cuda'):
    img = img.to(device)
    img.requires_grad = True
    model.zero_grad()
    model(img).sum().backward()
    result = img.grad.detach().cpu()
    model.zero_grad()
    return result

# Compute gradients for both models
robust_gradients = []
standard_gradients = []

for img, _ in tqdm(testloader):
    robust_gradients.append(input_gradient_sum(robust_model, img, device))
    standard_gradients.append(input_gradient_sum(standard_model, img, device))

robust_gradients = torch.cat(robust_gradients)
standard_gradients = torch.cat(standard_gradients)

# Load LPIPS model
loss_fn_alex = lpips.LPIPS(net='alex')

# Normalize scores and input gradients to range [-1, 1]
robust_gradients /= robust_gradients.abs().amax(dim=(1, 2, 3), keepdim=True)
standard_gradients /= standard_gradients.abs().amax(dim=(1, 2, 3), keepdim=True)

# Compute LPIPS distances
robust_lpips_distances = []
standard_lpips_distances = []

for idx in range(robust_gradients.shape[0]):
    robust_lpips_distances.append(loss_fn_alex(robust_gradients[idx].unsqueeze(0), robust_gradients[idx].unsqueeze(0)).item())
    standard_lpips_distances.append(loss_fn_alex(standard_gradients[idx].unsqueeze(0), standard_gradients[idx].unsqueeze(0)).item())

# Convert LPIPS distances to numpy arrays
robust_lpips_distances = np.array(robust_lpips_distances)
standard_lpips_distances = np.array(standard_lpips_distances)

# Save the results
np.save('robust_lpips_distances.npy', robust_lpips_distances)
np.save('standard_lpips_distances.npy', standard_lpips_distances)

print("LPIPS calculation completed and results are saved.")
