import numpy as np
import matplotlib.pyplot as plt
import torch
from torchvision import datasets, transforms
from models.model import ResNet18  # Assuming your model is defined in models/model.py

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load the test dataset
transform = transforms.Compose([transforms.ToTensor()])
testset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

# Load precomputed LPIPS distances
robust_lpips_distances = np.load('robust_lpips_distances.npy')
standard_lpips_distances = np.load('standard_lpips_distances.npy')

# Ensure correct indices for plotting
test_labels = np.array(testset.targets)
best_robust_indices = []

for class_id in range(10):
    class_indices = np.where(test_labels == class_id)[0]
    if len(class_indices) > 0:
        best_index_in_class = class_indices[np.argmin(robust_lpips_distances[class_indices])]
        best_robust_indices.append(best_index_in_class)

# Plot LPIPS results
nrows = 4  
ncols = len(best_robust_indices)  # Should be 10 for all CIFAR-10 classes
fig, axs = plt.subplots(nrows=nrows, ncols=ncols, figsize=(20, 12))

for i, idx in enumerate(best_robust_indices):
    # Original CIFAR-10 image
    img = testset.data[idx]
    axs[0, i].imshow(img)
    axs[0, i].axis('off')

    # Robust model's gradient
    robust_grad_img = (robust_gradients[idx].permute(1, 2, 0).numpy() * 127.5 + 128).clip(0, 255).astype(np.uint8)
    axs[2, i].imshow(robust_grad_img)
    axs[2, i].axis('off')
    axs[2, i].set_title(f"LPIPS: {robust_lpips_distances[idx]:.4f}")

    # Standard model's gradient
    standard_grad_img = (standard_gradients[idx].permute(1, 2, 0).numpy() * 127.5 + 128).clip(0, 255).astype(np.uint8)
    axs[3, i].imshow(standard_grad_img)
    axs[3, i].axis('off')
    axs[3, i].set_title(f"LPIPS: {standard_lpips_distances[idx]:.4f}")

plt.tight_layout()
plt.savefig('comparison_lpips_plot.png', dpi=1000)
plt.show()
