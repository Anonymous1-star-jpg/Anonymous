import numpy as np
import math
from scipy.special import gamma
from scipy.ndimage import gaussian_filter
import scipy.io
import skimage.transform
from skimage.color import rgb2gray
import matplotlib.pyplot as plt
from torchvision import datasets, transforms
from utils.utils import compute_niqe  # Assuming you have a function for NIQE calculation in utils.py

# Load CIFAR-10 images
transform = transforms.Compose([
    transforms.ToTensor(),
])

# Load CIFAR-10 dataset
cifar10_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
cifar10_loader = DataLoader(cifar10_dataset, batch_size=1, shuffle=False)

# Calculate NIQE score for each image
niqe_scores = []
for i, (image, _) in enumerate(cifar10_loader):
    # Convert to numpy, grayscale, and scale to 0-255
    image = image.numpy().squeeze().transpose(1, 2, 0)
    grayscale_image = rgb2gray(image) * 255.0

    # Calculate NIQE score
    niqe_score = compute_niqe(grayscale_image)
    niqe_scores.append(niqe_score)
    print(f"Image {i + 1} - NIQE Score: {niqe_score}")

# Save the NIQE scores
np.save('niqe_scores.npy', niqe_scores)

print("NIQE calculation completed and results are saved.")
