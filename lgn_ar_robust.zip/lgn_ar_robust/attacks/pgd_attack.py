import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from advertorch.attacks import LinfPGDAttack
from utils.utils import get_distance
from models.model import ResNet18  # Import your model definition

use_cuda = True
device = torch.device("cuda" if use_cuda else "cpu")

# Define the function for PGD attack
def pgd_attack(model, dataloader, criterion, epsilon=1/255, nb_iter=20):
    adversary = LinfPGDAttack(
        model, 
        loss_fn=nn.CrossEntropyLoss(reduction="sum"),
        eps=epsilon,  # Maximum perturbation
        nb_iter=nb_iter,  # Number of iterations (PGD20)
        eps_iter=epsilon / nb_iter,  # Step size for each iteration
        clip_min=0.0, 
        clip_max=1.0, 
        targeted=False)
    
    model.eval()
    start_time = time.time()
    
    running_loss = 0.
    running_corrects = 0
    running_l0, running_l2, running_mse, running_linf = 0, 0, 0, 0

    for i, (inputs, labels) in enumerate(dataloader):
        inputs, labels = inputs.to(device), labels.to(device)
    
        adv_untargeted = adversary.perturb(inputs, labels)  # Perform PGD attack
    
        outputs = model(adv_untargeted)
        _, preds = torch.max(outputs, 1)
        loss = criterion(outputs, labels)
    
        running_loss += loss.item()
        running_corrects += torch.sum(preds == labels.data)
    
        l0, l2, mse, linf = get_distance(adv_untargeted, inputs)
        running_l0 += l0.sum().item()
        running_l2 += l2.sum().item()
        running_mse += mse.sum().item()
        running_linf += linf.sum().item()

    epoch_loss = running_loss / len(dataloader.dataset)
    epoch_acc = running_corrects / len(dataloader.dataset) * 100.
    
    print('[PGD Attack] Loss: {:.4f} Accuracy: {:.4f}% Time elapsed: {:.4f}s'.format(
        epoch_loss, epoch_acc, time.time() - start_time))
    print('Average L0 distance:', running_l0 / len(dataloader.dataset))
    print('Average L2 distance:', running_l2 / len(dataloader.dataset))
    print('Average MSE:', running_mse / len(dataloader.dataset))
    print('Average Linf distance:', running_linf / len(dataloader.dataset))

if __name__ == "__main__":
    # Load your model
    model = ResNet18().to(device)
    model.load_state_dict(torch.load("model_path.pth")['state_dict'], strict=False)
    
    # Define test dataset
    transform_test = transforms.Compose([transforms.ToTensor()])
    test_dataset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
    test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=64, shuffle=False)

    criterion = nn.CrossEntropyLoss()

    pgd_attack(model, test_dataloader, criterion)
